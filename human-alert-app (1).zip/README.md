# Human Alert - Emergency Safety Network

## 📱 Build APK from Your Phone

### Step 1: Upload to GitHub
1. Create a new repository on GitHub
2. Upload all files from this ZIP
3. Ensure `frontend/` and `backend/` are at root level

### Step 2: Create Expo Account
Go to https://expo.dev/signup

### Step 3: Connect GitHub to Expo
1. Log into https://expo.dev
2. Create new project
3. Connect your GitHub repository
4. Select `frontend` as root directory

### Step 4: Build APK
1. Go to Builds → Create Build
2. Select Android → APK
3. Wait 10-15 minutes
4. Download APK!

## Features Included
- Emergency alert button
- Live map with directions
- Push notifications with sound
- Responder tracking
- 20-minute auto-end timer
- Smart radius expansion (300m→600m→1km)

## Backend URL
The app connects to:
https://safe-radius.preview.emergentagent.com

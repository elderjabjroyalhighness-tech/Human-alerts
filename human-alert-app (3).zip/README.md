# Human Alert - Emergency Safety Network

## Build APK from Phone

1. Upload to GitHub (create new repo, upload all files)
2. Create Expo account: https://expo.dev/signup
3. Connect GitHub repo to Expo
4. Build → Android → APK → Download

## Features
- Emergency button with 20-min auto-end
- Live map & directions
- Push notifications
- Responder tracking

## Backend: https://safe-radius.preview.emergentagent.com
